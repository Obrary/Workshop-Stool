Product: Workshop Stool, September 2014

Designer: 

Support:  http://forums.obrary.com/category/designs/workshop-stool

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
Here's a stool for the workshop.  It's effecient use of materials and can be milled from a 2'x4' sheet.  It can be made from MDF or plywood.  It snaps together.
